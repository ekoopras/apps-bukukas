<?php

namespace App\Filament\Resources\PendapatanResource\Pages;

use App\Filament\Resources\PendapatanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendapatan extends CreateRecord
{
    protected static string $resource = PendapatanResource::class;
}
